#ifndef RECTANGLE_H
#define RECTANGLE_H

class Rectangle: public Figure {
    public:
        void draw();
        void erase();
};


#endif

