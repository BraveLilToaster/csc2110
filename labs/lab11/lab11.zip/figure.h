#ifndef FIGURE_H
#define FIGURE_H

class Figure {
    public:

        void virtual draw();
        void virtual erase();
        void virtual center();
};


#endif

