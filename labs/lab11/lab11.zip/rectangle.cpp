#include<iostream>
#include "figure.h"
#include "rectangle.h"
using namespace std;


        void Rectangle::draw() {
            cout <<  "Rectangle::draw()" << endl;
        }
        void Rectangle::erase(){
            cout <<  "Rectangle::erase()" << endl;
        }
