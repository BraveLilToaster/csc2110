#include<iostream>
#include "figure.h"
#include "triangle.h"
using namespace std;


        void Triangle::draw() {
            cout <<  "Triangle::draw()" << endl;
        }
        void Triangle::erase(){
            cout <<  "Triangle::erase()" << endl;
        }
