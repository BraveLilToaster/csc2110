#ifndef TRIANGLE_H
#define TRIANGLE_H

class Triangle : public Figure {
    public:
        void draw();
        void erase();
};


#endif

