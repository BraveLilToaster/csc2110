#include<iostream>
#include "point.h"
#include "circle.h"
using namespce std;

int main(){

    Point p;
    Circle circ1;
    Circle circ2;

    p.area();
    p.distance();

}
    

